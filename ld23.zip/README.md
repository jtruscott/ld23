Ludum Dare 23!

I've been on a cycle of not-completing and completing these. This should be one of my good runs.

---

So here's the plan.

Tower defense game. ASCII console graphics.
The world starts out pitifully small, like 40x40 or something.
But it "pacmans" around like a torus (top of the map touches the bottom; left touches the right)
You are defending the north and south poles.
Enemies drop in from anywhere (except too near the poles, that'd be unfun).

And then the catch.
The map is growing.
After every wave new rows/columns of terrain just appear out of nowhere.
Spreading out your defenses.
Creating new weak points. 

---

Towers have a range of like 2-6 tiles around them. 
Upgrades sound like a good idea.
